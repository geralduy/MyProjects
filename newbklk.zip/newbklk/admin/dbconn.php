<?php 
	$conn = mysqli_connect("localhost","root","","practice") or die ('cannot connect to database' . mysqli_error());
?>