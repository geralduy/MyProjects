<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link href="jGrowl/jquery.jgrowl.css" rel="stylesheet" media="screen"/>
	<script src="js/jquery-1.9.1.min.js"></script>
	<?php include('dbconn.php'); ?>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>bklk.gov.ph</title>
	<link rel="icon" href="img/Bklk2.png">
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body class="bg-gradient-primary">
<div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
						<img src="img/Bklk2.png" class="logo col-lg-6 " alt="">
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
	   <form id="login_form"  method="post">
        
	   <h1 class="h4 text-gray-900 mb-4">Welcome Admin</h1>
        <input type="text" class="form-control form-control-user"  id="username" name="username" placeholder="Username" required><br><br>
        
        <input type="password"  class="form-control form-control-user" id="password" name="password" placeholder="Password" required><br>
		<p  class="float-left"><input type="checkbox" onclick="myFunction()" > Show Password</p>
		<script>
			   function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
		</script>
        <button name="login"class="btn btn-primary btn-user btn-block" type="submit">Sign in</button>
	
		      </form>
				<script>
			jQuery(document).ready(function(){
			jQuery("#login_form").submit(function(e){
					e.preventDefault();
					var formData = jQuery(this).serialize();
					$.ajax({
						type: "POST",
						url: "login.php",
						data: formData,
						success: function(html){
						if(html=='true')
						{
						$.jGrowl("Welcome Back!", { header: 'Access Granted' });
						var delay = 0;
							setTimeout(function(){ window.location = 'home.php'  }, delay);  
						}
						else
						{
						$.jGrowl("Please Check your username and Password", { header: 'Login Failed' });
						}
						}
						
					});
					return false;
				});
			});
			</script>  

  
  
		</div>
		</div><!--form-->
		
		<br><br>
		
		
		
		            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
			
<br>
</center>
<?php include('scripts.php');?>

</body>
</html>
